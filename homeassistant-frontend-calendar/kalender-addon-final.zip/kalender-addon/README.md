# Annes Kalender – HA Add-on

Kalender-Oberfläche für den Home Assistant Local Calendar direkt als Add-on.

## Installation

1. In HA: **Einstellungen → Add-ons → Add-on Store → ⋮ → Benutzerdefinierte Repositories**
2. Diesen Ordner als lokales Repository eintragen:  
   Pfad auf dem HA-Host: `/config/kalender-addon` (oder via Git-URL)
3. Add-on **"Annes Kalender"** installieren
4. Konfiguration anpassen:
   - `ics_path`: Pfad zur ICS-Datei (Standard passt für `calendar.anne_arbeit`)
   - `ha_token`: Long-Lived Access Token (Profil → Sicherheit)
5. Add-on starten → erscheint in der HA-Seitenleiste

## Lokale Installation (ohne Git)

```bash
# Auf dem HA-Host:
mkdir -p /config/kalender-addon
cp -r kalender/ /config/kalender-addon/
```

Dann in HA als Custom Repository `/config/kalender-addon` eintragen.

## Unterschiede zur LXC-Version

- Kein SSH nötig — liest ICS direkt via `/config`-Mount
- Erscheint als Tab in der HA-Seitenleiste (Ingress)
- HA-Token wird automatisch vom Supervisor bereitgestellt
