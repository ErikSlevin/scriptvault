from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import json
import uuid
import requests
from datetime import datetime, date
from icalendar import Calendar, Event, vText
from zoneinfo import ZoneInfo
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

LOCAL_TZ = ZoneInfo("Europe/Berlin")

# Ingress root path vom Supervisor
root_path = os.environ.get("INGRESS_PATH", "")

app = FastAPI(title="Annes Kalender", root_path=root_path)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

CONFIG_PATH = "/app/config.json"
with open(CONFIG_PATH) as f:
    CONFIG = json.load(f)

ICS_PATH = CONFIG.get("ics_path", "/config/.storage/local_calendar.anne_arbeit.ics")


def read_ics() -> bytes:
    with open(ICS_PATH, "rb") as f:
        return f.read()


def write_ics(content: bytes):
    # Backup
    if os.path.exists(ICS_PATH):
        with open(ICS_PATH + ".bak", "wb") as f:
            f.write(read_ics())
    with open(ICS_PATH, "wb") as f:
        f.write(content)


def ha_reload():
    try:
        ha_url = CONFIG.get("ha_url", "").rstrip("/")
        ha_token = CONFIG.get("ha_token", "")
        if not ha_url or not ha_token:
            logger.warning("ha_url oder ha_token fehlt — HA-Reload übersprungen")
            return
        headers = {"Authorization": f"Bearer {ha_token}", "Content-Type": "application/json"}
        # Services API — einfacher und braucht kein hassio_api
        r = requests.post(
            f"{ha_url}/api/services/homeassistant/reload_config_entry",
            headers=headers,
            json={"entity_id": "calendar.anne_arbeit"},
            timeout=5
        )
        logger.info(f"HA Calendar neu geladen ✓ ({r.status_code})")
    except Exception as ex:
        logger.warning(f"HA-Reload fehlgeschlagen: {ex}")

def ics_to_events(content: bytes) -> list:
    cal = Calendar.from_ical(content)
    events = []
    for component in cal.walk():
        if component.name != "VEVENT":
            continue
        try:
            dtstart = component.get("DTSTART").dt
            dtend = component.get("DTEND").dt
            all_day = isinstance(dtstart, date) and not isinstance(dtstart, datetime)
            if not all_day:
                if hasattr(dtstart, 'tzinfo') and dtstart.tzinfo:
                    dtstart = dtstart.astimezone(LOCAL_TZ)
                if hasattr(dtend, 'tzinfo') and dtend.tzinfo:
                    dtend = dtend.astimezone(LOCAL_TZ)
            events.append({
                "uid": str(component.get("UID", "")),
                "summary": str(component.get("SUMMARY", "")),
                "description": str(component.get("DESCRIPTION", "")),
                "start": dtstart.isoformat(),
                "end": dtend.isoformat(),
                "all_day": all_day,
            })
        except Exception as e:
            logger.warning(f"Event übersprungen: {e}")
    return events


class EventIn(BaseModel):
    summary: str
    description: Optional[str] = ""
    start_date: str
    end_date: str
    all_day: bool = True
    start_time: Optional[str] = "00:00"
    end_time: Optional[str] = "01:00"


@app.get("/", response_class=HTMLResponse)
def index():
    with open("/app/templates/index.html", encoding="utf-8") as f:
        return f.read()


@app.get("/api/events")
def get_events(year: int, month: int, wide: int = 0):
    try:
        content = read_ics()
        all_events = ics_to_events(content)
        month_start = date(year, month, 1)
        month_end = date(year + 1, 1, 1) if month == 12 else date(year, month + 1, 1)
        result = []
        for e in all_events:
            try:
                ev_start = date.fromisoformat(e["start"][:10])
                ev_end = date.fromisoformat(e["end"][:10])
                if ev_start < month_end and ev_end >= month_start:
                    result.append(e)
            except Exception:
                pass
        return result
    except Exception as ex:
        logger.error(f"Fehler beim Lesen: {ex}")
        raise HTTPException(status_code=500, detail=str(ex))


@app.post("/api/events")
def create_event(ev: EventIn):
    try:
        content = read_ics()
        cal = Calendar.from_ical(content)
        new_ev = Event()
        new_ev.add("SUMMARY", ev.summary)
        new_ev.add("DESCRIPTION", ev.description or "")
        new_ev.add("UID", str(uuid.uuid4()))
        new_ev.add("DTSTAMP", datetime.utcnow())
        new_ev.add("CREATED", datetime.utcnow())
        new_ev.add("SEQUENCE", 0)
        if ev.all_day:
            new_ev.add("DTSTART", date.fromisoformat(ev.start_date))
            new_ev.add("DTEND", date.fromisoformat(ev.end_date))
        else:
            new_ev.add("DTSTART", datetime.fromisoformat(f"{ev.start_date}T{ev.start_time}:00"))
            new_ev.add("DTEND", datetime.fromisoformat(f"{ev.end_date}T{ev.end_time}:00"))
        cal.add_component(new_ev)
        write_ics(cal.to_ical())
        ha_reload()
        return {"status": "ok"}
    except Exception as ex:
        logger.error(f"Fehler beim Erstellen: {ex}")
        raise HTTPException(status_code=500, detail=str(ex))


@app.put("/api/events/{uid}")
def update_event(uid: str, ev: EventIn):
    try:
        content = read_ics()
        cal = Calendar.from_ical(content)
        new_cal = Calendar()
        for attr in ["VERSION", "PRODID", "CALSCALE", "METHOD"]:
            if cal.get(attr):
                new_cal.add(attr, cal[attr])
        found = False
        for component in cal.walk():
            if component.name == "VEVENT":
                if str(component.get("UID")) == uid:
                    found = True
                    component["SUMMARY"] = vText(ev.summary)
                    component["DESCRIPTION"] = vText(ev.description or "")
                    for key in ["DTSTART", "DTEND"]:
                        if key in component:
                            del component[key]
                    if ev.all_day:
                        component.add("DTSTART", date.fromisoformat(ev.start_date))
                        component.add("DTEND", date.fromisoformat(ev.end_date))
                    else:
                        component.add("DTSTART", datetime.fromisoformat(f"{ev.start_date}T{ev.start_time}:00"))
                        component.add("DTEND", datetime.fromisoformat(f"{ev.end_date}T{ev.end_time}:00"))
                new_cal.add_component(component)
            elif component.name != "VCALENDAR":
                new_cal.add_component(component)
        if not found:
            raise HTTPException(status_code=404, detail="Ereignis nicht gefunden")
        write_ics(new_cal.to_ical())
        ha_reload()
        return {"status": "ok"}
    except HTTPException:
        raise
    except Exception as ex:
        logger.error(f"Fehler beim Bearbeiten: {ex}")
        raise HTTPException(status_code=500, detail=str(ex))


@app.delete("/api/events/{uid}")
def delete_event(uid: str):
    try:
        content = read_ics()
        cal = Calendar.from_ical(content)
        new_cal = Calendar()
        for attr in ["VERSION", "PRODID", "CALSCALE", "METHOD"]:
            if cal.get(attr):
                new_cal.add(attr, cal[attr])
        deleted = False
        for component in cal.walk():
            if component.name == "VEVENT":
                if str(component.get("UID")) == uid:
                    deleted = True
                    continue
                new_cal.add_component(component)
            elif component.name != "VCALENDAR":
                new_cal.add_component(component)
        if not deleted:
            raise HTTPException(status_code=404, detail="Ereignis nicht gefunden")
        write_ics(new_cal.to_ical())
        ha_reload()
        return {"status": "ok"}
    except HTTPException:
        raise
    except Exception as ex:
        logger.error(f"Fehler beim Löschen: {ex}")
        raise HTTPException(status_code=500, detail=str(ex))
