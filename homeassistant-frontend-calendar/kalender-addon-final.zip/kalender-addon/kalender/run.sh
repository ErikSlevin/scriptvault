#!/bin/sh

ICS_PATH=$(python3 -c "import json; d=json.load(open('/data/options.json')); print(d.get('ics_path','/config/.storage/local_calendar.anne_arbeit.ics'))")
HA_URL=$(python3 -c "import json; d=json.load(open('/data/options.json')); print(d.get('ha_url','http://supervisor/core'))")
HA_TOKEN=$(python3 -c "import json; d=json.load(open('/data/options.json')); print(d.get('ha_token',''))")

cat > /app/config.json << CONF
{
  "ics_path": "${ICS_PATH}",
  "ha_url": "${HA_URL}",
  "ha_token": "${HA_TOKEN}"
}
CONF

# Ingress path für FastAPI
export INGRESS_PATH="${INGRESS_ENTRY:-}"

echo "Annes Kalender startet auf Port 8000 (Ingress: ${INGRESS_PATH})..."
exec uvicorn app:app --host 0.0.0.0 --port 8000 --app-dir /app --root-path "${INGRESS_PATH}"
